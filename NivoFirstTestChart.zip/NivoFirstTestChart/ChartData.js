//Age Range according to the gender dataset - Shavini Saparamadu
export default[
    {
      Age : "0-18",
      Female: 0,      
      Male: 1,
      Other: 0,
      
    },
    {
       Age : "19-24",
       Female: 3,      
       Male: 7,
       Other: 0,

    },
    {
      Age: "25-29",
      Female: 3,      
      Male: 3,
      Other: 0,

     
    },
    {
      Age: "30-34",
      Female: 10,            
      Male: 15,
      Other: 1,
     

    },
    {
      Age: "35-39",
      Female: 7,      
      Male: 30,
      Other: 0,

    },
    {
      Age: "40-44",
      Female: 5,      
      Male: 14,
      Other: 0,

    },
    {
      Age: "45-49",
      Female: 2,      
      Male: 7,
      Other: 0,

    },
    {
      Age: "50-54",
      Female: 1,      
      Male: 1,
      Other: 0,

    },
    {
      Age: "55-59",
      Female: 0,      
      Male: 0,
      Other: 0,

    },
    {
      Age: "60-64",
      Female: 0,      
      Male: 0,
      Other: 2,

    },
    {
      Age: "65-100",
      Female: 0,      
      Male: 0,
      Other: 0,
      
    }
  ]